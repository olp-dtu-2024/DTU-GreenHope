module.exports = require('./dist/server/index.js');
